# Source material

This folder carries the planning artifacts that shaped the presentation. They are reference material, not the projected deck.

- `agentic-work-presentation-plan.md` — detailed presentation blueprint.
- `agentic-work-presentation-plan.html` — browser-readable version of the blueprint.
- `voice-memo-transcript.txt` — raw speech-to-text source; internal names may be incorrect.

When the package is moved to the work computer, verify internal terms against approved sources before copying them into the presentation.
