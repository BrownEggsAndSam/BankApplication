# Work-computer handoff

## Objective

Finish the evidence and internal terminology in `from-buzzwords-to-better-work.html` without changing its core story:

> A business professional used a hybrid role and agentic tools to bridge business intent and technical execution; four familiar workflows show the value; the responsible next step is a repeatable use-case intake and bounded pilot—not copying one person’s laptop setup.

The 18-slide narrative and speaker notes are already implemented. Preserve the sequence unless an internal reviewer requests a change.

## Canonical presentation files

- Main story: `from-buzzwords-to-better-work.html`
- Main story content and notes: `buzzwords-deck.js`
- Shared presentation behavior: `presentation.js`
- Shared visual design: `presentation.css`
- Screenshot folder and checklist: `assets/work/`
- Presentation library: `index.html`

Open `index.html` directly in a browser. The deck requires no server, installation, credentials, or network connection.

## Work-computer assignment

1. Verify internal names and replace uncertain terms only when the official wording is known:
   - Full meaning of EDMG.
   - Official name and role of Ask Genie.
   - Whether ICR and EDQ are personas, agents, skills, or domains.
   - Formal name of the EDG Scorecard initiative.
   - Formal database modernization / vend issue name.
   - Official platform name that voice transcription rendered as DTCE or DGCE.
   - Correct enterprise initiative names that the transcript rendered unclearly.

2. Confirm each maturity badge. A badge describes maturity, not enterprise approval:
   - **Working today:** proven in the presenter’s controlled local workspace.
   - **Prototype:** working or partly working, still being tuned or validated.
   - **Concept:** proposed future workflow, operating model, or scale path.

3. Create or select one approved, sanitized landscape montage for each named slot in `assets/work/README.md`. Use the exact filenames so the deck replaces the placeholders automatically.

4. Confirm the post-presentation support path before inviting teams to submit use cases:
   - Intake owner.
   - Business sponsor.
   - Approved sandbox or pilot environment.
   - Technical review and escalation path.
   - Data and tool approval owner.
   - Skill ownership and maintenance process.
   - Provisioning path if multiple teams request help.

5. Replace future measures with real baseline and pilot results only when evidence exists. Do not invent time savings, accuracy, adoption, or backlog reduction.

## Image and data safety

Do not inspect, copy, print, upload, or package `.env` files, tokens, API keys, connection strings, credentials, unrestricted production exports, or personal files.

Use staged screenshots, dummy data, or approved redacted examples. Every image must remove names, faces, email addresses, message subjects, ticket identifiers, database hosts and schemas, URLs, account names, internal UUIDs, producer/customer records, and confidential text.

The personal and gaming photos found on the non-work computer are intentionally excluded and must remain excluded.

## Validation checklist

- Open `index.html` while disconnected from the network.
- Open all three decks from the library.
- Check every main-story slide at 1280×720 or a comparable 16:9 projector size.
- Confirm arrow-key and Space navigation.
- Press `N` and review every speaker note.
- Use Print / PDF and confirm one 16:9 slide per page.
- Confirm no broken image icon appears when a screenshot is absent.
- Search the final package for tokens, secrets, personal information, internal URLs, and unredacted identifiers.
- Confirm the call to action names a real support path or remains labeled **Decision needed**.

## Ready-to-send prompt for the work agent

> Review this presentation package using the local work context available on this computer. Preserve the 18-slide narrative in `from-buzzwords-to-better-work.html` and `buzzwords-deck.js`. Your job is to verify internal terminology, confirm each Working today / Prototype / Concept label, fill only the five named screenshot slots under `assets/work/`, and complete the real support and intake path. Use staged or sanitized evidence. Never inspect or copy `.env` files, tokens, secrets, credentials, unrestricted production data, personal files, or unrelated screenshots. Do not invent performance claims. Keep consequential actions human-owned. After edits, test offline opening, 1280×720 slide fit, keyboard navigation, notes, and Print / PDF. Report every term, image, maturity label, and support-path field that still needs human confirmation.
