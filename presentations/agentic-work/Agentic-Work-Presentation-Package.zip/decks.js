window.PRESENTATION_DECKS = {
  team: {
    title: "From Personal Prototype to a Reusable Business Agent",
    shortTitle: "Team capability",
    slides: [
      {
        label: "From personal prototype to team capability",
        tone: "ink",
        html: `
          <div class="cover-grid">
            <div>
              <p class="eyebrow eyebrow--light">EDMG • BUSINESS AGENT STRATEGY</p>
              <h1>From personal prototype<br />to team capability.</h1>
            </div>
            <div class="cover-bottom">
              <p class="cover-deck">Make the workflow easier.<br />Package it once.<br />Prove it safely.</p>
              <p class="cover-meta">A practical proposal for a nontechnical business team</p>
            </div>
          </div>`,
        note: `<p>Open with the outcome: this is not a request to build an enterprise agent platform. It is a proposal to turn a proven personal workflow into one bounded, reusable business capability.</p>`
      },
      {
        label: "What already works",
        tone: "paper",
        html: `
          <p class="eyebrow">CURRENT STATE</p>
          <h2>You have already proven the hard part:<br />grounded agent work creates value.</h2>
          <div class="evidence-wall">
            <article class="mock-window">
              <div class="mock-bar"><span></span><span></span><span></span><b>workspace / context</b></div>
              <div class="mock-code"><em>personas/</em><strong>edmg-router.md</strong><strong>business-analyst.md</strong><strong>data-investigator.md</strong></div>
            </article>
            <article class="mock-window mock-window--dark">
              <div class="mock-bar"><span></span><span></span><span></span><b>read-only query</b></div>
              <div class="mock-terminal"><i>$</i> python vend_status.py<br /><mark>✓</mark> PostgreSQL connected<br /><mark>✓</mark> evidence returned</div>
            </article>
            <article class="mock-window">
              <div class="mock-bar"><span></span><span></span><span></span><b>work management</b></div>
              <div class="mock-story"><small>JIRA STORY</small><strong>Draft acceptance criteria</strong><span>Dependencies • questions • sources</span></div>
            </article>
            <article class="mock-window">
              <div class="mock-bar"><span></span><span></span><span></span><b>API specifications</b></div>
              <div class="endpoint-list"><span><b>GET</b> Collibra assets</span><span><b>POST</b> Pentaho job status</span><span><b>GET</b> source metadata</span></div>
            </article>
          </div>
          <p class="evidence-caption">Sanitized reconstruction of the current prototype: Markdown personas, Python, PostgreSQL, Jira / Confluence, and OpenAPI specifications.</p>`,
        note: `<p>This visual intentionally reconstructs the environment without exposing credentials, URLs, issue details, or company-confidential screenshots. The point is the range of capability already demonstrated.</p>`
      },
      {
        label: "The gap is distribution",
        tone: "mist",
        html: `
          <p class="eyebrow">THE ACTUAL PROBLEM</p>
          <div class="statement-layout">
            <h2>The gap is distribution—<br />not intelligence.</h2>
            <div class="equation">
              <span>Proven prototype</span><b>+</b><span>nontechnical team</span><b>≠</b><span class="equation-accent">supported service</span>
            </div>
            <div class="friction-rail">
              <span><b>Local</b> context and scripts</span>
              <span><b>Personal</b> credentials</span>
              <span><b>Technical</b> judgment</span>
              <span><b>No</b> production front door</span>
            </div>
          </div>`,
        note: `<p>Emphasize that asking everyone to learn GitHub Copilot, repositories, environment files, and API behavior will not scale. The product challenge is packaging, access, trust, and support.</p>`
      },
      {
        label: "Start with tasks",
        tone: "paper",
        html: `
          <p class="eyebrow">PRODUCT SHAPE</p>
          <h2>Start with repeatable tasks.<br />Do not start with a general chatbot.</h2>
          <div class="task-lanes">
            <div class="task-lane"><span>01</span><strong>Enrich a Jira story</strong><p>Acceptance criteria, dependencies, risks, and open questions.</p><small>LOWER RISK</small></div>
            <div class="task-lane"><span>02</span><strong>Answer a process question</strong><p>Use approved context and return the sources behind the answer.</p><small>LOWER RISK</small></div>
            <div class="task-lane"><span>03</span><strong>Investigate a daily vend</strong><p>Read status and evidence from approved PostgreSQL views.</p><small>CONTROLLED READ</small></div>
            <div class="task-lane"><span>04</span><strong>Draft API or BPMN design</strong><p>Translate OpenAPI definitions into a reviewable technical artifact.</p><small>SPECIALIST REVIEW</small></div>
          </div>`,
        note: `<p>A task has a clear input, output, owner, source boundary, and success test. That makes it easier to register, approve, measure, and support than an open-ended assistant.</p>`
      },
      {
        label: "Recommended first use case",
        tone: "aqua",
        html: `
          <div class="pilot-feature">
            <div>
              <p class="eyebrow">RECOMMENDED FIRST USE CASE</p>
              <h2>Jira story<br />enrichment.</h2>
              <p class="pilot-lede">Read the story and approved context. Produce a sourced draft. Let the owner decide what gets published.</p>
            </div>
            <div class="before-after">
              <div class="story-before"><small>BEFORE</small><strong>One-paragraph request</strong><span>Scope is implied. Dependencies are missing.</span></div>
              <div class="story-arrow">→</div>
              <div class="story-after"><small>AFTER</small><strong>Review-ready draft</strong><span>Acceptance criteria • dependencies • risks • questions • sources</span></div>
            </div>
          </div>
          <div class="reason-strip"><span>Already proven</span><span>Read-oriented</span><span>Human-reviewed</span><span>Auditable output</span><span>Concrete gateway use case</span></div>`,
        note: `<p>This is the strongest first registration candidate because it demonstrates value without beginning with database writes or production automation. API/BPMN drafting can be a supporting task in the same pilot.</p>`
      },
      {
        label: "One front door and multiple specialists",
        tone: "ink",
        html: `
          <p class="eyebrow eyebrow--light">TARGET EXPERIENCE</p>
          <h2>One front door.<br />Multiple specialists behind it.</h2>
          <div class="orchestration-map">
            <div class="map-request"><small>PLAIN-LANGUAGE REQUEST</small><strong>“Help me finish this story.”</strong></div>
            <div class="map-line"></div>
            <div class="map-router"><small>EDMG ORCHESTRATOR</small><strong>Intent • risk • depth • plan</strong><span>Clarify when confidence is low</span></div>
            <div class="map-branches">
              <div><small>BUSINESS ANALYST</small><strong>Stories & outcomes</strong></div>
              <div><small>KNOWLEDGE</small><strong>Sources & citations</strong></div>
              <div><small>DATA INVESTIGATOR</small><strong>PostgreSQL evidence</strong></div>
              <div><small>API / PROCESS</small><strong>OpenAPI & BPMN</strong></div>
              <div><small>GOVERNANCE</small><strong>Controls & quality</strong></div>
            </div>
          </div>
          <p class="map-caption">The user does not select an agent. EDMG routes the work and never grants itself additional permissions.</p>`,
        note: `<p>Clarify that the Markdown personas are a strong foundation, but true orchestration also needs explicit routing, permission checks, tool contracts, evidence collection, and audit logic.</p>`
      },
      {
        label: "What the user experiences",
        tone: "paper",
        html: `
          <p class="eyebrow">NONTECHNICAL BY DESIGN</p>
          <h2>The team sees a simple workflow.<br />The complexity stays behind it.</h2>
          <div class="experience-flow">
            <article><span>1</span><small>ASK</small><strong>Describe the outcome</strong><p>“Expand this Jira story and show me what is missing.”</p></article>
            <div class="flow-connector"></div>
            <article><span>2</span><small>CHOOSE DEPTH</small><strong>Brief, Business, or Technical</strong><p>Control the explanation—not the permissions.</p></article>
            <div class="flow-connector"></div>
            <article><span>3</span><small>REVIEW</small><strong>See the answer and sources</strong><p>Approve any follow-up action explicitly.</p></article>
          </div>
          <div class="simple-promise">No repository. No agent selection. No API vocabulary. No silent write.</div>`,
        note: `<p>This slide is the adoption promise. The first interface can be a supported internal form, command surface, or approved gateway experience; it does not have to be a fully featured production chat UI on day one.</p>`
      },
      {
        label: "How every request is controlled",
        tone: "mist",
        html: `
          <p class="eyebrow">CONTROL FLOW</p>
          <h2>Every request passes the same gates.</h2>
          <ol class="control-flow">
            <li><span>01</span><strong>Classify</strong><small>intent</small></li>
            <li><span>02</span><strong>Check</strong><small>risk + access</small></li>
            <li><span>03</span><strong>Plan</strong><small>bounded tasks</small></li>
            <li><span>04</span><strong>Delegate</strong><small>persona + tools</small></li>
            <li><span>05</span><strong>Collect</strong><small>evidence</small></li>
            <li><span>06</span><strong>Validate</strong><small>quality + policy</small></li>
            <li class="control-final"><span>07</span><strong>Human review</strong><small>before use or action</small></li>
          </ol>
          <div class="guardrail-banner">Default for the pilot: read-only systems, draft-only output, explicit human approval.</div>`,
        note: `<p>The orchestrator coordinates the control flow. Access is still determined by enterprise identity, the connector, and the approved use case—not by the persona prompt.</p>`
      },
      {
        label: "Constraints define the pilot",
        tone: "paper",
        html: `
          <p class="eyebrow">DESIGNING WITH REAL CONSTRAINTS</p>
          <h2>Constraints define the pilot.<br />They do not end it.</h2>
          <div class="constraint-table">
            <div class="constraint-head">CURRENT CONSTRAINT</div><div class="constraint-head">DESIGN RESPONSE</div>
            <div><strong>No Bedrock without a registered asset</strong><p>AI Dome Gateway requires a concrete use case.</p></div><div><strong>Register one business outcome</strong><p>Owner, source boundary, expected value, volume, and risk envelope.</p></div>
            <div><strong>No approved MCP servers</strong><p>The business team cannot stand up a broad integration layer.</p></div><div><strong>Use narrow approved adapters</strong><p>HTTPS APIs, read-only views, explicit contracts, and audit logs—never a policy bypass.</p></div>
            <div><strong>No production agent UI</strong><p>Nontechnical users cannot depend on a developer workspace.</p></div><div><strong>Begin with a supported task surface</strong><p>Simple request → sourced draft → human review. Standardize the UI later.</p></div>
          </div>`,
        note: `<p>The phrase “workaround” can alarm risk partners. Position direct adapters as a temporary, governed bridge that can later be replaced by approved MCP servers without changing the user workflow.</p>`
      },
      {
        label: "Package once and configure per team",
        tone: "ink",
        html: `
          <p class="eyebrow eyebrow--light">THE REUSABLE PRODUCT</p>
          <h2>Package once.<br />Configure per team.</h2>
          <div class="kit-stack">
            <div class="kit-layer kit-layer--top"><small>TEAM CONFIGURATION</small><strong>Use cases • sources • vocabulary • owners</strong></div>
            <div class="kit-layer"><small>PERSONA PACK</small><strong>Business analyst • data • API/process • governance</strong></div>
            <div class="kit-layer"><small>TOOL ADAPTERS</small><strong>Jira / Confluence • PostgreSQL • Collibra • Pentaho</strong></div>
            <div class="kit-layer"><small>CONTROL CORE</small><strong>EDMG routing • permissions • evidence • audit</strong></div>
            <div class="kit-layer kit-layer--bottom"><small>ENABLEMENT</small><strong>Tests • runbook • examples • onboarding • support</strong></div>
          </div>
          <p class="kit-principle">Teams should configure the kit—not copy personal tokens, fork scripts, or rewrite the core.</p>`,
        note: `<p>This is the “ship to other teams” model. A team brings its approved sources, owners, and tasks. The shared kit supplies orchestration, contracts, tests, and support patterns.</p>`
      },
      {
        label: "Two separate control dials",
        tone: "paper",
        html: `
          <p class="eyebrow">AVOID A COMMON DESIGN MISTAKE</p>
          <h2>Depth and autonomy are<br />two separate control dials.</h2>
          <div class="dial-layout">
            <div class="dial-card">
              <small>HOW THE ANSWER IS EXPLAINED</small>
              <div class="depth-dial"><span>BRIEF</span><span>BUSINESS</span><span>TECHNICAL</span></div>
              <p>A technical answer can still be advice-only.</p>
            </div>
            <div class="dial-card">
              <small>WHAT THE AGENT MAY DO</small>
              <div class="autonomy-dial"><span>EXPLAIN</span><span>READ</span><span class="dial-active">DRAFT</span><span>EXECUTE</span></div>
              <p>A business-friendly request can still require restricted data.</p>
            </div>
          </div>
          <div class="pilot-position">PILOT POSITION <strong>Any explanation depth • Read + Draft authority • Human review</strong></div>`,
        note: `<p>Separating these dials makes the experience safer and clearer. “Technical mode” should not quietly mean “more permissions.”</p>`
      },
      {
        label: "A 90-day path",
        tone: "mist",
        html: `
          <p class="eyebrow">PROPOSED ROADMAP</p>
          <h2>A 90-day pilot can create<br />the evidence needed for approval.</h2>
          <div class="roadmap">
            <article><span>0–30</span><strong>Define</strong><p>Name the use case, owners, data boundary, no-write guardrail, and success scorecard. Curate the first knowledge pack.</p></article>
            <article><span>31–60</span><strong>Build + test</strong><p>Package EDMG and personas, create read-only adapters, add audit evidence, and test against known stories.</p></article>
            <article><span>61–90</span><strong>Prove + decide</strong><p>Run with two teams, measure usefulness and rework, complete the risk review, and decide the next gate.</p></article>
          </div>
          <div class="roadmap-gates"><span>GATE 1 • USE CASE REGISTERED</span><span>GATE 2 • CONTROLS PASS</span><span>GATE 3 • VALUE PROVEN</span></div>`,
        note: `<p>Do not promise full production UI or database/API execution in 90 days. Promise evidence: value, control effectiveness, user fit, and a clearer production decision.</p>`
      },
      {
        label: "Decision requested",
        tone: "coral",
        html: `
          <p class="eyebrow">DECISION REQUESTED</p>
          <h1>Approve a bounded,<br />read-only pilot.</h1>
          <div class="decision-list">
            <span><b>01</b> Jira story enrichment as the registered use case</span>
            <span><b>02</b> A business product owner and technical / security partner</span>
            <span><b>03</b> Draft-only output, human review, and an auditable gateway path</span>
          </div>
          <p class="decision-close">Earn the right to scale—one controlled outcome at a time.</p>`,
        note: `<p>End on the smallest actionable decision. The ask is not approval for a production multi-agent platform. It is approval to create the evidence needed for the next decision.</p>`
      }
    ]
  },

  durable: {
    title: "Building the Agent to Last",
    shortTitle: "Long-term operating model",
    slides: [
      {
        label: "Building the agent to last",
        tone: "ink",
        html: `
          <div class="cover-grid">
            <div>
              <p class="eyebrow eyebrow--light">EDMG • LONG-TERM OPERATING MODEL</p>
              <h1>Build the agent<br />to last.</h1>
            </div>
            <div class="cover-bottom">
              <p class="cover-deck">Useful as systems change.<br />Safe as access grows.<br />Supportable beyond one owner.</p>
              <p class="cover-meta">A durability plan for product, technology, risk, and operations</p>
            </div>
          </div>`,
        note: `<p>Frame “work long” as long-term sustainability: the agent should remain accurate, governed, maintainable, and useful as people, policies, data, and APIs change.</p>`
      },
      {
        label: "The durability test",
        tone: "paper",
        html: `
          <p class="eyebrow">THE DURABILITY TEST</p>
          <h2>If one change breaks the service,<br />it is still a personal prototype.</h2>
          <div class="survival-list">
            <div><span>01</span><strong>An API changes</strong><p>Does the agent fail safely and tell the user what changed?</p></div>
            <div><span>02</span><strong>A database schema changes</strong><p>Do tests detect it before users receive a confident wrong answer?</p></div>
            <div><span>03</span><strong>An owner leaves</strong><p>Can a named steward operate and update the service?</p></div>
            <div><span>04</span><strong>Teams context becomes stale</strong><p>Does content expire, get reviewed, and retain its source?</p></div>
            <div><span>05</span><strong>A security review begins</strong><p>Can we show permissions, versions, sources, and decision logs?</p></div>
          </div>`,
        note: `<p>These are practical tests for durability. They shift the conversation from “the prompt works” to “the service can be trusted over time.”</p>`
      },
      {
        label: "Treat the agent as a product",
        tone: "aqua",
        html: `
          <p class="eyebrow">OPERATING PRINCIPLE</p>
          <h2>Treat the agent as a product—<br />not a collection of prompts.</h2>
          <div class="ownership-orbit">
            <div class="orbit-core"><small>EDMG SERVICE</small><strong>Outcome + controls + support</strong></div>
            <div class="orbit-item orbit-1"><small>BUSINESS</small><strong>Product owner</strong></div>
            <div class="orbit-item orbit-2"><small>TECHNOLOGY</small><strong>Technical steward</strong></div>
            <div class="orbit-item orbit-3"><small>DATA</small><strong>Source owners</strong></div>
            <div class="orbit-item orbit-4"><small>RISK</small><strong>Security / governance</strong></div>
            <div class="orbit-item orbit-5"><small>BEHAVIOR</small><strong>Persona owners</strong></div>
            <div class="orbit-item orbit-6"><small>ADOPTION</small><strong>Team champions</strong></div>
          </div>
          <p class="orbit-caption">Every capability needs a named owner, version, test, and review date.</p>`,
        note: `<p>The business team should own the outcome and roadmap, but it cannot own every technical and security control alone. This is a small cross-functional product, not a handoff.</p>`
      },
      {
        label: "An architecture that can evolve",
        tone: "ink",
        html: `
          <p class="eyebrow eyebrow--light">MODULAR BY DESIGN</p>
          <h2>Separate the layers so each one<br />can change without a rebuild.</h2>
          <div class="architecture-layers">
            <div><small>EXPERIENCE</small><strong>Task form • chat • scheduled trigger</strong><span>Replace the UI later</span></div>
            <div><small>ORCHESTRATION</small><strong>EDMG routing • planning • evidence</strong><span>Keep the workflow stable</span></div>
            <div><small>POLICY</small><strong>Identity • access • action gates</strong><span>Independent enforcement</span></div>
            <div><small>SPECIALISTS</small><strong>Persona packs • task logic</strong><span>Version behavior safely</span></div>
            <div><small>CONNECTORS</small><strong>Jira • PostgreSQL • Collibra • Pentaho</strong><span>Swap adapters for MCP later</span></div>
            <div><small>OPERATIONS</small><strong>Tests • logs • feedback • support</strong><span>Evidence across every layer</span></div>
          </div>`,
        note: `<p>This is the long-term payoff of modularity: the company can add an approved UI, model gateway, or MCP implementation without rewriting the business workflow and personas.</p>`
      },
      {
        label: "Separate what changes at different speeds",
        tone: "mist",
        html: `
          <p class="eyebrow">CHANGE MANAGEMENT</p>
          <h2>Not everything should be released<br />at the same speed.</h2>
          <div class="speed-stack">
            <div class="speed-fast"><span>DAILY / WEEKLY</span><strong>Team context</strong><p>Approved facts, links, terminology, examples.</p></div>
            <div><span>WEEKLY / MONTHLY</span><strong>Persona instructions</strong><p>Task behavior, quality checks, output patterns.</p></div>
            <div><span>MONTHLY / QUARTERLY</span><strong>Tool contracts</strong><p>Inputs, outputs, permissions, schema and API versions.</p></div>
            <div><span>CONTROLLED RELEASE</span><strong>Core routing + policy</strong><p>EDMG logic, action tiers, identity and audit requirements.</p></div>
          </div>
          <p class="speed-principle">Team-specific changes must not fork the shared core.</p>`,
        note: `<p>This prevents a common failure mode: every team copies the folder, edits the prompts, and creates an unsupported branch. Configuration should move quickly; core controls should move carefully.</p>`
      },
      {
        label: "Create a persona and tool registry",
        tone: "paper",
        html: `
          <p class="eyebrow">CONTROL THE COMPONENTS</p>
          <h2>Create a registry before<br />personas and scripts multiply.</h2>
          <div class="registry-table">
            <div class="registry-head">COMPONENT</div><div class="registry-head">PURPOSE</div><div class="registry-head">OWNER</div><div class="registry-head">ACCESS</div><div class="registry-head">VERSION / TEST</div>
            <div><strong>Business Analyst</strong><small>PERSONA</small></div><div>Enrich work items</div><div>Product owner</div><div>Approved Jira context</div><div>v1.3 • 12 scenarios</div>
            <div><strong>Data Investigator</strong><small>PERSONA</small></div><div>Assemble vend evidence</div><div>Data steward</div><div>Read-only views</div><div>v0.8 • 9 scenarios</div>
            <div><strong>Jira adapter</strong><small>TOOL</small></div><div>Read issue + context</div><div>Technical steward</div><div>Read scope</div><div>v1.1 • contract test</div>
            <div><strong>PostgreSQL adapter</strong><small>TOOL</small></div><div>Query approved views</div><div>Data platform</div><div>Named views only</div><div>v0.6 • schema test</div>
          </div>
          <p class="registry-footer">Each entry also declares sensitivity, input/output schema, action tier, review date, and retirement path.</p>`,
        note: `<p>The values shown are illustrative. The point is the registry schema: purpose, owner, access, version, tests, and lifecycle. Markdown changes can alter behavior and therefore need the same discipline.</p>`
      },
      {
        label: "Turn Teams knowledge into governed context",
        tone: "paper",
        html: `
          <p class="eyebrow">KNOWLEDGE LIFECYCLE</p>
          <h2>Curate Teams knowledge.<br />Do not dump chat history into the agent.</h2>
          <div class="knowledge-pipeline">
            <article><span>01</span><strong>Select</strong><p>An owner chooses decisions, procedures, and useful examples.</p></article>
            <article><span>02</span><strong>Normalize</strong><p>Convert to source-linked text with consistent metadata.</p></article>
            <article><span>03</span><strong>Classify</strong><p>Add sensitivity, audience, and permitted use.</p></article>
            <article><span>04</span><strong>Review</strong><p>Confirm accuracy, owner, effective date, and conflicts.</p></article>
            <article><span>05</span><strong>Retrieve</strong><p>Use only relevant chunks and cite the original source.</p></article>
            <article><span>06</span><strong>Expire</strong><p>Review or remove stale content automatically.</p></article>
          </div>
          <div class="knowledge-metadata"><span>OWNER</span><span>SOURCE</span><span>EFFECTIVE DATE</span><span>SENSITIVITY</span><span>REVIEW DATE</span></div>`,
        note: `<p>This pipeline turns informal team memory into a governed knowledge product. It also gives the agent a safe fallback: if context is expired or conflicting, ask for review rather than inventing an answer.</p>`
      },
      {
        label: "Replace personal secrets with managed identity",
        tone: "coral",
        html: `
          <p class="eyebrow">IDENTITY AND SECRETS</p>
          <h2>Local <code>.env</code> files prove the prototype.<br />They cannot be the distribution model.</h2>
          <div class="identity-path">
            <div class="identity-now"><small>NOW</small><strong>Personal token</strong><span>Local environment file</span><span>One operator</span><span>Hard to revoke and audit</span></div>
            <div class="identity-transition">→</div>
            <div class="identity-next"><small>TARGET</small><strong>Managed identity</strong><span>Per-user or service authorization</span><span>Least privilege + short-lived access</span><span>Central revocation and audit</span></div>
          </div>
          <div class="identity-rules"><span>No secrets in prompts</span><span>No shared personal tokens</span><span>Read-only by default</span><span>Separate identity per environment</span></div>`,
        note: `<p>The prototype was appropriate for learning. Shipping to teams requires an identity and secret-management path owned with technology and security partners.</p>`
      },
      {
        label: "Increase autonomy through explicit gates",
        tone: "ink",
        html: `
          <p class="eyebrow eyebrow--light">EARN AUTONOMY WORKFLOW BY WORKFLOW</p>
          <h2>More autonomy is a release decision—<br />not a model setting.</h2>
          <div class="autonomy-ladder">
            <div><span>L0</span><strong>Explain</strong><p>No system access</p></div>
            <div><span>L1</span><strong>Read</strong><p>Approved sources</p></div>
            <div class="ladder-current"><span>L2</span><strong>Draft</strong><p>Human-reviewed output</p><small>PILOT TARGET</small></div>
            <div><span>L3</span><strong>Execute</strong><p>Confirmation required</p></div>
            <div><span>L4</span><strong>Schedule</strong><p>Approved automation + monitoring</p></div>
          </div>
          <p class="ladder-caption">A workflow advances only after its value, failure modes, identity, tests, and monitoring are proven.</p>`,
        note: `<p>Do not grant a universal autonomy level to the whole agent. Jira drafting might reach Level 2 while a data correction stays at Level 1 for much longer.</p>`
      },
      {
        label: "Engineer for source and tool changes",
        tone: "paper",
        html: `
          <p class="eyebrow">CONNECTOR RESILIENCE</p>
          <h2>A failing tool must produce<br />a clear limitation—not a confident guess.</h2>
          <div class="resilience-diagram">
            <div class="resilience-request"><small>REQUEST</small><strong>Investigate today’s vend</strong></div>
            <div class="resilience-checks">
              <div><b>1</b><span>Schema / contract check</span></div>
              <div><b>2</b><span>Permission + data boundary</span></div>
              <div><b>3</b><span>Timeout, retry, idempotency</span></div>
              <div><b>4</b><span>Evidence + freshness check</span></div>
            </div>
            <div class="resilience-outcomes">
              <div class="outcome-good"><small>PASS</small><strong>Sourced result</strong><span>Tool version + timestamp</span></div>
              <div class="outcome-safe"><small>FAIL SAFELY</small><strong>Clear limitation</strong><span>What failed • what was not checked • next step</span></div>
            </div>
          </div>
          <div class="test-strip"><span>OPENAPI CONTRACT TESTS</span><span>POSTGRESQL SCHEMA CHECKS</span><span>MOCKED CONNECTORS</span><span>SAFE FALLBACKS</span></div>`,
        note: `<p>Build failure behavior deliberately. The agent should never fill a missing tool response with plausible language. This is one of the biggest differences between a demo and a dependable service.</p>`
      },
      {
        label: "Observe every run",
        tone: "mist",
        html: `
          <p class="eyebrow">OBSERVABILITY WITHOUT OVERSHARING</p>
          <h2>Record enough to improve and audit.<br />Redact what does not belong in a log.</h2>
          <div class="run-record">
            <div class="run-header"><span>RUN • 2026-07-19 • 10:42</span><b>COMPLETED WITH REVIEW</b></div>
            <dl>
              <div><dt>Request type</dt><dd>Jira story enrichment</dd></div>
              <div><dt>Route</dt><dd>EDMG → Business Analyst → Knowledge</dd></div>
              <div><dt>Versions</dt><dd>router 1.4 • personas 1.3 / 1.1 • adapter 1.1</dd></div>
              <div><dt>Sources</dt><dd>3 approved sources • links retained</dd></div>
              <div><dt>Outcome</dt><dd>Draft accepted after 2 edits</dd></div>
              <div><dt>Quality</dt><dd>Evidence complete • no write attempted</dd></div>
            </dl>
          </div>
          <div class="redaction-banner">Do not log raw secrets, unnecessary personal data, full prompts containing restricted content, or uncontrolled model traces.</div>`,
        note: `<p>The record is illustrative. Good telemetry lets the team answer: what work is requested, how it was routed, what sources were used, what failed, and whether users accepted the result.</p>`
      },
      {
        label: "Release changes like a shared service",
        tone: "paper",
        html: `
          <p class="eyebrow">RELEASE DISCIPLINE</p>
          <h2>Persona Markdown can change behavior.<br />Release it like a service.</h2>
          <div class="release-line">
            <article><small>01</small><strong>Develop</strong><p>Change one component and document the intent.</p></article>
            <article><small>02</small><strong>Test</strong><p>Regression scenarios, contract tests, and risk checks.</p></article>
            <article><small>03</small><strong>Pilot</strong><p>Named users, real tasks, monitored outcomes.</p></article>
            <article><small>04</small><strong>Release</strong><p>Versioned package, notes, owner, rollback.</p></article>
            <article><small>05</small><strong>Review</strong><p>Feedback, incidents, stale content, next gate.</p></article>
          </div>
          <div class="environment-strip"><span>DEVELOPMENT</span><span>TEST</span><span>PRODUCTION</span><span>ROLLBACK READY</span></div>`,
        note: `<p>The control should be proportional. A wording correction is not the same as a new tool permission, but both deserve traceability and a known rollback point.</p>`
      },
      {
        label: "Support adoption",
        tone: "aqua",
        html: `
          <p class="eyebrow">THE SERVICE AROUND THE AGENT</p>
          <h2>Nontechnical teams adopt trusted outcomes—<br />not agent architecture.</h2>
          <div class="service-catalog">
            <div class="catalog-feature"><small>VISIBLE FRONT DOOR</small><strong>“What can this help me do?”</strong><p>A task catalog with examples, expected inputs, outputs, sources, and limits.</p></div>
            <div><small>GUIDES</small><strong>Task-based examples</strong><p>Show the best request, not prompt engineering theory.</p></div>
            <div><small>PEOPLE</small><strong>Champion network</strong><p>Office hours, feedback, and peer support.</p></div>
            <div><small>SUPPORT</small><strong>Clear escalation</strong><p>Where errors, access issues, and bad answers go.</p></div>
            <div><small>TRUST</small><strong>Visible limits</strong><p>Sources, freshness, permissions, and human responsibility.</p></div>
          </div>`,
        note: `<p>A usable service catalog is often more important than another persona. It tells people what the agent is for, what good looks like, and where to go when it fails.</p>`
      },
      {
        label: "Long-term investment decision",
        tone: "coral",
        html: `
          <p class="eyebrow">GATED INVESTMENT</p>
          <h2>Fund the capability in phases.<br />Make every phase earn the next.</h2>
          <div class="investment-phases">
            <article><span>PHASE 1</span><strong>Reusable Agent Kit</strong><p>Read-only connectors, curated context, draft outputs, human review.</p><small>GATE: VALUE + CONTROL EVIDENCE</small></article>
            <article><span>PHASE 2</span><strong>Governed shared service</strong><p>AI Dome path, managed identity, monitoring, support, two or more teams.</p><small>GATE: RELIABILITY + ADOPTION</small></article>
            <article><span>PHASE 3</span><strong>Production experience</strong><p>Approved UI, standardized connectors / MCP, carefully gated actions.</p><small>GATE: WORKFLOW-SPECIFIC APPROVAL</small></article>
          </div>
          <div class="final-ask"><small>DECISION NOW</small><strong>Name the product owner and technical steward. Approve the control baseline and first-year scorecard.</strong></div>`,
        note: `<p>Close with the long-term organizational decision: ownership and control baseline first, technology phases second. Each phase is funded only after the preceding value and risk gates are met.</p>`
      }
    ]
  }
};
