# Approved work-image folder

The presentation automatically replaces its labeled placeholders when approved images with these exact names are placed in this folder:

- `00-current-agent-workspace.png`
- `01-outlook-governed-draft.png`
- `02-scorecard-prompt-to-prototype.png`
- `03-postgresql-vend-comparison.png`
- `04-rationalization-review-queue.png`

Use a 16:9 or wide landscape crop. A single sanitized montage is preferable to several tiny screenshots.

Before adding an image, remove names, faces, email addresses, ticket identifiers, database hosts and schemas, URLs, account names, producer/customer records, internal UUIDs, tokens, secrets, connection details, and confidential text. Never copy `.env` files or credentials into this folder.

Update `manifest.json` only after the image has been reviewed. The deck works offline and does not read the manifest at runtime; it is a human and agent checklist.
