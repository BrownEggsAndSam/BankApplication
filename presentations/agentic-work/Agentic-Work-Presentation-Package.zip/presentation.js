(function () {
  const deckKey = document.body.dataset.deck;
  const deck = window.PRESENTATION_DECKS?.[deckKey];
  const app = document.getElementById("presentation-app");

  if (!deck || !app) {
    document.body.innerHTML = '<main class="fatal"><h1>Presentation unavailable</h1><p>Return to <a href="index.html">the presentation library</a>.</p></main>';
    return;
  }

  const deckCycle = {
    buzzwords: { href: "team-adoption.html", label: "Team Capability Deck" },
    team: { href: "building-to-last.html", label: "Building the Agent to Last" },
    durable: { href: "from-buzzwords-to-better-work.html", label: "Main Story Deck" }
  };
  const otherDeck = deckCycle[deckKey] || { href: "index.html", label: "Presentation Library" };

  app.innerHTML = `
    <header class="presentation-header">
      <a class="header-home" href="index.html" aria-label="Back to presentation library">${deck.brand || "EDMG"}</a>
      <div class="header-title">${deck.shortTitle}</div>
      <div class="header-progress" aria-hidden="true"><span></span></div>
      <div class="header-count" aria-live="polite">1 / ${deck.slides.length}</div>
    </header>

    <main class="slides" aria-label="${deck.title}">
      ${deck.slides.map((slide, index) => `
        <section class="slide tone-${slide.tone || "paper"}" id="slide-${index + 1}" data-index="${index}" tabindex="-1" aria-label="Slide ${index + 1}: ${slide.label}">
          <div class="slide-frame">
            <div class="slide-content">${slide.html}</div>
            <div class="slide-number" aria-hidden="true">${String(index + 1).padStart(2, "0")}</div>
          </div>
          <aside class="presenter-note" aria-label="Speaker notes"><strong>Speaker note</strong>${slide.note}</aside>
        </section>
      `).join("")}
    </main>

    <nav class="presentation-controls" aria-label="Presentation controls">
      <button type="button" class="control-button" data-action="previous" aria-label="Previous slide">←</button>
      <button type="button" class="control-button" data-action="next" aria-label="Next slide">→</button>
      <span class="control-separator" aria-hidden="true"></span>
      <button type="button" class="text-button" data-action="notes">Notes</button>
      <button type="button" class="text-button" data-action="fullscreen">Full screen</button>
      <button type="button" class="text-button" data-action="print">Print / PDF</button>
      <a class="text-button deck-switch" href="${otherDeck.href}">${otherDeck.label}</a>
    </nav>
  `;

  document.querySelectorAll(".evidence-slot img").forEach((image) => {
    const slot = image.closest(".evidence-slot");
    const markLoaded = () => slot?.classList.add("has-image");
    const markMissing = () => slot?.classList.remove("has-image");
    image.addEventListener("load", markLoaded);
    image.addEventListener("error", markMissing);
    if (image.complete && image.naturalWidth > 0) markLoaded();
  });

  const slides = Array.from(document.querySelectorAll(".slide"));
  const progress = document.querySelector(".header-progress span");
  const count = document.querySelector(".header-count");
  let current = 0;

  function update(index, updateHash = true) {
    current = Math.max(0, Math.min(slides.length - 1, index));
    progress.style.width = `${((current + 1) / slides.length) * 100}%`;
    count.textContent = `${current + 1} / ${slides.length}`;
    slides.forEach((slide, i) => slide.classList.toggle("is-current", i === current));
    if (updateHash) history.replaceState(null, "", `#slide-${current + 1}`);
  }

  function go(index) {
    const target = Math.max(0, Math.min(slides.length - 1, index));
    slides[target].scrollIntoView({ behavior: "smooth", block: "start" });
    update(target);
  }

  const observer = new IntersectionObserver((entries) => {
    const visible = entries
      .filter((entry) => entry.isIntersecting)
      .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (visible) update(Number(visible.target.dataset.index));
  }, { threshold: [0.55, 0.75] });
  slides.forEach((slide) => observer.observe(slide));

  document.addEventListener("keydown", (event) => {
    if (["ArrowRight", "ArrowDown", "PageDown", " "].includes(event.key)) {
      event.preventDefault();
      go(current + 1);
    } else if (["ArrowLeft", "ArrowUp", "PageUp"].includes(event.key)) {
      event.preventDefault();
      go(current - 1);
    } else if (event.key === "Home") {
      event.preventDefault();
      go(0);
    } else if (event.key === "End") {
      event.preventDefault();
      go(slides.length - 1);
    } else if (event.key.toLowerCase() === "n") {
      document.body.classList.toggle("show-notes");
    } else if (event.key.toLowerCase() === "f") {
      document.documentElement.requestFullscreen?.();
    } else if (event.key === "Escape" && document.body.classList.contains("show-notes")) {
      document.body.classList.remove("show-notes");
    }
  });

  document.querySelector("[data-action='previous']").addEventListener("click", () => go(current - 1));
  document.querySelector("[data-action='next']").addEventListener("click", () => go(current + 1));
  document.querySelector("[data-action='notes']").addEventListener("click", () => document.body.classList.toggle("show-notes"));
  document.querySelector("[data-action='fullscreen']").addEventListener("click", () => document.documentElement.requestFullscreen?.());
  document.querySelector("[data-action='print']").addEventListener("click", () => window.print());

  const initial = Number((location.hash.match(/slide-(\d+)/) || [])[1] || 1) - 1;
  update(initial, false);
  if (initial > 0) requestAnimationFrame(() => slides[initial].scrollIntoView({ block: "start" }));
})();
