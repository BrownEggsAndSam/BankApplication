(function () {
  const badge = (label, kind) => `<span class="status-badge status-${kind}">${label}</span>`;
  const asset = (file, title, caption, callouts = []) => `
    <figure class="evidence-slot" data-asset-id="${file.replace(/\.[^.]+$/, "")}">
      <div class="slot-placeholder" aria-hidden="true">
        <div class="slot-toolbar"><i></i><i></i><i></i><span>SANITIZED EVIDENCE SLOT</span></div>
        <div class="slot-body">
          <small>DROP APPROVED WORK IMAGE</small>
          <strong>${title}</strong>
          <code>assets/work/${file}</code>
          ${callouts.length ? `<div class="slot-callouts">${callouts.map((item, index) => `<span><b>${index + 1}</b>${item}</span>`).join("")}</div>` : ""}
        </div>
      </div>
      <img src="assets/work/${file}" alt="${title}" />
      <figcaption>${caption}</figcaption>
    </figure>`;

  window.PRESENTATION_DECKS = window.PRESENTATION_DECKS || {};
  window.PRESENTATION_DECKS.buzzwords = {
    brand: "AGENTIC",
    title: "From AI Buzzwords to Better Work",
    shortTitle: "Buzzwords → better work",
    slides: [
      {
        label: "From AI buzzwords to better work",
        tone: "ink",
        html: `
          <div class="cover-grid buzz-cover">
            <div>
              <p class="eyebrow eyebrow--light">AGENTIC WORK • DATA GOVERNANCE</p>
              <h1>From AI buzzwords<br />to better work.</h1>
            </div>
            <div class="cover-bottom">
              <p class="cover-deck">You do not need to become a developer.</p>
              <p class="cover-meta">You need to become an effective designer, reviewer, and owner of agent-enabled work.</p>
            </div>
          </div>`,
        note: `<p>This is not a coding lesson. It is a practical story about where agents can fit into work that business teams already understand better than anyone else. The promise: by the end, people should be able to identify one task, describe the skill it needs, and recognize the controls required to test it safely.</p>`
      },
      {
        label: "My role became a bridge",
        tone: "paper",
        html: `
          <div class="slide-topline"><p class="eyebrow">THE PERSONAL STORY</p>${badge("WORKING TODAY", "working")}</div>
          <h2>My role became a bridge between business intent and technical execution.</h2>
          <div class="hybrid-bridge">
            <div class="bridge-side"><small>BUSINESS EXPERTISE</small><strong>Rules • context • outcomes • exceptions</strong><p>I knew what the work needed to accomplish.</p></div>
            <div class="bridge-span"><span>DIRECT</span><span>TEACH</span><span>VERIFY</span><span>OWN</span></div>
            <div class="bridge-side bridge-side--dark"><small>TECHNICAL EXECUTION</small><strong>Scripts • APIs • data • prototypes</strong><p>Agents helped me translate intent into artifacts technology could react to.</p></div>
          </div>
          <p class="thesis-strip">The gap is rarely a lack of ideas. It is the distance between what the business means and what technology can safely build.</p>`,
        note: `<p>Tell this in first person. Over the past year, working in a hybrid role made the gap visible: business teams own the meaning, but technical delivery depends on requirements, examples, data definitions, and reviewable artifacts. Agents made it possible to cross more of that distance without pretending technical expertise is no longer needed.</p>`
      },
      {
        label: "What is working locally",
        tone: "mist",
        html: `
          <div class="slide-topline"><p class="eyebrow">PROOF ON ONE LAPTOP</p>${badge("WORKING TODAY", "working")}</div>
          <h2>The pieces are real—even though they are not yet a supported product.</h2>
          <div class="proof-layout">
            ${asset("00-current-agent-workspace.png", "Current local agent workspace", "Replace with one approved, redacted overview of the local setup.", ["Agent context", "Scripts and data", "Persona files"])}
            <div class="proof-list">
              <article><span>01</span><strong>Local agent context</strong><p>Work instructions and multiple governance personas.</p></article>
              <article><span>02</span><strong>Grounded access</strong><p>Python with read-oriented PostgreSQL analysis.</p></article>
              <article><span>03</span><strong>Work systems</strong><p>Personal Jira and Confluence access for story context.</p></article>
              <article><span>04</span><strong>Technical references</strong><p>Collibra and Pentaho OpenAPI specifications.</p></article>
            </div>
          </div>
          <p class="boundary-strip"><b>PERSONAL PROTOTYPE</b> Local credentials, personal judgment, and a developer workspace are not a team distribution model.</p>`,
        note: `<p>Be precise: this is proof of usefulness in a controlled personal workspace, not proof that the capability is approved for broad use. Show one redacted environment overview later. Never show environment files, tokens, URLs, database identifiers, private Jira content, or confidential records.</p>`
      },
      {
        label: "Less rework, not more AI output",
        tone: "coral",
        html: `
          <div class="slide-topline"><p class="eyebrow">THE QUALITY TEST</p>${badge("WORKING PRINCIPLE", "working")}</div>
          <h2>The goal is not more AI output.<br />It is less rework.</h2>
          <div class="workslop-compare">
            <section class="workslop-card"><small>WORKSLOP</small><strong>Looks finished.<br />Creates cleanup.</strong><ul><li>Vague request</li><li>Polished but ungrounded</li><li>No test for “good”</li><li>Forwarded without ownership</li></ul></section>
            <div class="compare-arrow">→</div>
            <section class="useful-card"><small>USEFUL AGENTIC WORK</small><strong>Grounded draft.<br />Owned result.</strong><ul><li>Clear outcome and context</li><li>Approved sources</li><li>Acceptance criteria</li><li>Human verifies and owns</li></ul></section>
          </div>
          <p class="thesis-strip thesis-strip--dark">AI moves effort from first-draft creation toward direction, judgment, and verification. It does not remove accountability.</p>`,
        note: `<p>Address workslop early. People can recognize polished nonsense, and they worry it will create more work for them. The differentiator is not how impressive the draft looks; it is whether the output is grounded, testable, reviewable, and owned.</p>`
      },
      {
        label: "Agent skill and harness",
        tone: "paper",
        html: `
          <div class="slide-topline"><p class="eyebrow">THREE CONCEPTS ARE ENOUGH</p>${badge("MENTAL MODEL", "concept")}</div>
          <h2>Agent. Skill. Harness.<br />One durable mental model.</h2>
          <div class="concept-triad">
            <article><span>01</span><small>AGENT</small><strong>The capable analyst</strong><p>Pursues the goal across several steps and adapts along the way.</p></article>
            <article><span>02</span><small>SKILL</small><strong>The organization’s playbook</strong><p>Rules, examples, definitions, exceptions, and a recognizable good result.</p></article>
            <article><span>03</span><small>HARNESS</small><strong>The controlled workstation</strong><p>Approved context, tools, permissions, limits, tests, and review points.</p></article>
          </div>
          <div class="human-owner"><small>HUMAN</small><strong>The accountable owner</strong><span>Directs • teaches • verifies • approves</span></div>`,
        note: `<p>Use the analyst analogy throughout. A general analyst may know how to compare two lists. A rationalization skill teaches our exact criteria and exceptions. The harness determines what the analyst may read, which tool it may use, and where a person must approve the result.</p>`
      },
      {
        label: "Human checkpoints",
        tone: "aqua",
        html: `
          <div class="slide-topline"><p class="eyebrow">THE REPEATABLE WORKFLOW</p>${badge("PROTOTYPE PATTERN", "prototype")}</div>
          <h2>The human stays in the loop—and in charge.</h2>
          <div class="gate-labels"><span><b>BEFORE</b>Is the request, data, and access appropriate?</span><span><b>DURING</b>Does the logic and evidence make sense?</span><span><b>AFTER</b>Should this be sent, changed, or used?</span></div>
          <ol class="human-gate-flow">
            <li><span>01</span><strong>Business goal</strong></li>
            <li><span>02</span><strong>Approved context</strong></li>
            <li><span>03</span><strong>Skill applied</strong></li>
            <li><span>04</span><strong>Approved tool</strong></li>
            <li><span>05</span><strong>Draft / analysis</strong></li>
            <li class="gate-final"><span>06</span><strong>Human verifies</strong></li>
            <li class="gate-final"><span>07</span><strong>Human acts</strong></li>
          </ol>`,
        note: `<p>Return to this flow during every use case. The human check can happen before, during, and after—not just as a disclaimer at the end. Generated scripts are still code; generated queries still touch real data; generated drafts still require an owner.</p>`
      },
      {
        label: "EDMG routes specialists",
        tone: "ink",
        html: `
          <div class="slide-topline"><p class="eyebrow eyebrow--light">ORCHESTRATION IN PLAIN LANGUAGE</p>${badge("PROTOTYPE", "prototype")}</div>
          <h2>One front door.<br />The right expertise behind it.</h2>
          <div class="router-visual">
            <div class="router-request"><small>BUSINESS REQUEST</small><strong>“Help me finish this work.”</strong></div>
            <div class="router-line"></div>
            <div class="router-core"><small>EDMG ORCHESTRATOR</small><strong>Intent • risk • plan • route</strong><span>Clarifies when confidence is low</span></div>
            <div class="router-line"></div>
            <div class="router-personas"><span>ICR / policy</span><span>EDQ / quality</span><span>Stewardship</span><span>Data investigation</span><span>API / process</span></div>
          </div>
          <p class="router-rule">The orchestrator coordinates work. It never grants itself more access.</p>`,
        note: `<p>This is the evolution of the Custom GPT persona idea. EDMG should classify the request and route the bounded work to the right persona or skill. Confirm the official meaning of EDMG, Ask Genie, ICR, and EDQ before presenting those names as established architecture.</p>`
      },
      {
        label: "Four familiar problems",
        tone: "mist",
        html: `
          <p class="eyebrow">THE WORKDAY PORTFOLIO</p>
          <h2>Four familiar problems show where agents fit.</h2>
          <div class="usecase-portfolio">
            <article><div><span>01</span>${badge("PROTOTYPE", "prototype")}</div><strong>Find + route</strong><p>Outlook request → governed draft</p><small>LESS SEARCHING</small></article>
            <article><div><span>02</span>${badge("PROTOTYPE", "prototype")}</div><strong>Translate</strong><p>Business idea → story + prototype</p><small>LESS AMBIGUITY</small></article>
            <article><div><span>03</span>${badge("PROTOTYPE", "prototype")}</div><strong>Compare</strong><p>PostgreSQL → vend evidence</p><small>LESS MANUAL RECONCILIATION</small></article>
            <article><div><span>04</span>${badge("CONCEPT", "concept")}</div><strong>Apply rules</strong><p>Records → rationalization review</p><small>MORE CONSISTENCY</small></article>
          </div>
          <p class="thesis-strip">These are not four chatbots. They are four workflows with recognizable inputs, rules, tools, outputs, and review points.</p>`,
        note: `<p>Invite the audience to watch for the same pattern in every case: agent, skill, harness, and human checkpoint. The status badges describe maturity, not approval. A working local prototype may still be unapproved for team use.</p>`
      },
      {
        label: "Use case one Outlook to governed draft",
        tone: "paper",
        html: `
          <div class="case-heading"><div><p class="eyebrow">USE CASE 01 • FIND + ROUTE</p><h2>From Outlook request<br />to governed draft.</h2></div>${badge("PROTOTYPE", "prototype")}</div>
          <div class="case-layout">
            ${asset("01-outlook-governed-draft.png", "Outlook request and governed draft", "Illustrative slot—use a staged message and remove names, addresses, subjects, IDs, and confidential text.", ["Approved sender", "Domain route", "Draft only"])}
            <div class="case-details">
              <div class="case-flow"><span>Outlook filter</span><b>→</b><span>Intent</span><b>→</b><span>Ask Genie / domain skill</span><b>→</b><span>Draft</span></div>
              <dl><div><dt>AGENT</dt><dd>Coordinates retrieval, routing, and drafting.</dd></div><div><dt>SKILL</dt><dd>Email interpretation, domain routing, response rules.</dd></div><div><dt>HARNESS</dt><dd>Approved sender scope, Outlook access, no auto-send.</dd></div><div><dt>HUMAN</dt><dd>Checks the source, edits the answer, and sends.</dd></div></dl>
              <p class="case-truth"><b>Working locally:</b> targeted email retrieval. <b>Still to prove:</b> supported team access and end-to-end routing.</p>
            </div>
          </div>`,
        note: `<p>Do not turn this into a PowerShell lesson. The business story is that the agent reduces context switching: find the relevant request, understand intent, apply the right guidance, and prepare a draft. Use a staged email, a tiny annotated mechanism, and a visible human-review checkpoint. Never open a live inbox during the presentation.</p>`
      },
      {
        label: "Use case two business idea to buildable prototype",
        tone: "aqua",
        html: `
          <div class="case-heading"><div><p class="eyebrow">USE CASE 02 • TRANSLATE</p><h2>Turn a business idea into something technology can build.</h2></div>${badge("PROTOTYPE", "prototype")}</div>
          <div class="case-layout case-layout--reverse">
            <div class="case-details">
              <div class="prompt-journey"><article><small>1 • SAY IT NATURALLY</small><strong>Conversational requirement</strong><p>Rules, exceptions, examples, and frustration included.</p></article><article><small>2 • TUNE IT</small><strong>Clarifying questions</strong><p>What is missing? What counts? What happens at the edge?</p></article><article><small>3 • MAKE IT VISIBLE</small><strong>Story + HTML prototype</strong><p>A shared object for business and technology to review.</p></article></div>
              <p class="case-truth"><b>The prototype is a communication artifact.</b> It is not the production application.</p>
            </div>
            ${asset("02-scorecard-prompt-to-prototype.png", "EDG Scorecard prompt evolution and prototype", "Use an approved, sanitized montage: original prompt → tuning loop → prototype and acceptance criteria.", ["Original intent", "Corrections", "Reviewable result"])}
          </div>`,
        note: `<p>The revision trail is the proof—not the first output. Show the original conversational prompt, what the agent misunderstood or asked, how your judgment changed the result, and the final prototype plus acceptance criteria. This is how a business owner can reduce requirement ambiguity without claiming the prototype is production ready.</p>`
      },
      {
        label: "Use case three database versus vend",
        tone: "ink",
        html: `
          <div class="case-heading"><div><p class="eyebrow eyebrow--light">USE CASE 03 • COMPARE</p><h2>Compare the database with what producers vend.</h2></div>${badge("PROTOTYPE", "prototype")}</div>
          <div class="case-layout">
            ${asset("03-postgresql-vend-comparison.png", "PostgreSQL versus daily vend comparison", "Use dummy or fully sanitized values. Remove hosts, schemas, producer names, identifiers, and production data.", ["Database value", "Vended value", "Difference to verify"])}
            <div class="case-details case-details--light">
              <div class="case-flow case-flow--light"><span>Plain-language question</span><b>→</b><span>Read-only query</span><b>→</b><span>Compare</span><b>→</b><span>Explain exceptions</span></div>
              <dl><div><dt>QUESTION</dt><dd>What actually exists versus what was vended?</dd></div><div><dt>SCOPE</dt><dd>One approved domain object, such as a dataset or glossary entry.</dd></div><div><dt>CONTROL</dt><dd>Named read-only views, query limits, and no writes.</dd></div><div><dt>VALIDATION</dt><dd>Domain owner confirms the discrepancy before it becomes a finding.</dd></div></dl>
              <p class="case-truth case-truth--light"><b>Working locally:</b> PostgreSQL connectivity and read scripts. <b>Still to prove:</b> reproducible shared reconciliation.</p>
            </div>
          </div>`,
        note: `<p>Keep SQL small and secondary. The proof is a reproducible comparison with evidence. Be clear that local PostgreSQL connectivity exists, while the completed end-to-end reconciliation remains a prototype unless you can show a validated example. Mention Collibra only when the object and terminology are confirmed.</p>`
      },
      {
        label: "Use case four rationalization skill",
        tone: "mist",
        html: `
          <div class="case-heading"><div><p class="eyebrow">USE CASE 04 • APPLY RULES</p><h2>Turn rationalization knowledge into a reusable skill.</h2></div>${badge("CONCEPT", "concept")}</div>
          <div class="case-layout case-layout--reverse">
            <div class="case-details">
              <div class="skill-recipe"><span>Definition of a match</span><span>Normalization rules</span><span>Confidence bands</span><span>Known exceptions</span><span>Required evidence</span><span>Reviewer instructions</span></div>
              <div class="rational-flow"><span>Candidate records</span><b>→</b><span>Scored recommendation</span><b>→</b><span>Review queue</span><b>→</b><strong>Steward decides</strong></div>
              <p class="case-truth"><b>The agent may recommend.</b> A steward retains every merge, retire, delete, or escalation decision.</p>
            </div>
            ${asset("04-rationalization-review-queue.png", "Rationalization candidates and steward review queue", "Use dummy records and a staged recommendation. Do not expose real names, IDs, protected terms, or disposition decisions.", ["Rule applied", "Evidence", "Human decision"])}
          </div>`,
        note: `<p>A successful prompt helps once. A versioned skill helps repeatedly. Explain that the business team—not a general model—must define matching rules, exceptions, confidence thresholds, evidence requirements, and the reviewer’s decision path.</p>`
      },
      {
        label: "One repeatable design",
        tone: "paper",
        html: `
          <p class="eyebrow">THE TRANSFERABLE PATTERN</p>
          <h2>Different workflows.<br />One repeatable design.</h2>
          <div class="pattern-six">
            <article><span>01</span><strong>Trigger</strong><p>What starts the work?</p></article>
            <article><span>02</span><strong>Rules</strong><p>What expertise guides it?</p></article>
            <article><span>03</span><strong>Inputs</strong><p>What context is approved?</p></article>
            <article><span>04</span><strong>Tools</strong><p>What may the agent use?</p></article>
            <article><span>05</span><strong>Output</strong><p>What artifact is useful?</p></article>
            <article><span>06</span><strong>Checkpoint</strong><p>What must a person decide?</p></article>
          </div>
          <div class="case-pattern-rail"><span>EMAIL</span><span>SCORECARD</span><span>DATABASE</span><span>RATIONALIZATION</span><strong>Same design questions</strong></div>`,
        note: `<p>This is where the examples stop being “Sam’s setup” and become a method teams can reuse. If a workflow cannot identify these six parts, it is not ready to become an agent use case.</p>`
      },
      {
        label: "The scaling blocker is the harness",
        tone: "coral",
        html: `
          <div class="slide-topline"><p class="eyebrow">THE REAL CURRENT STATE</p>${badge("CONSTRAINTS TODAY", "working")}</div>
          <h2>The scaling blocker is the harness—not a lack of ideas.</h2>
          <div class="constraint-grid constraint-grid--buzz">
            <article><span>01</span><strong>No supported production UI</strong><p>Nontechnical teams cannot depend on a developer workspace.</p></article>
            <article><span>02</span><strong>AI Dome needs a use case</strong><p>Bedrock access requires a registered asset and concrete business outcome.</p></article>
            <article><span>03</span><strong>No approved MCP servers</strong><p>Tool access needs an approved, narrow path—not an improvised bypass.</p></article>
            <article><span>04</span><strong>Personal tokens do not scale</strong><p>Shared capability requires identity, least privilege, and support.</p></article>
            <article><span>05</span><strong>Teams context is not agent context</strong><p>Useful decisions must become reviewed, source-linked knowledge packs.</p></article>
          </div>
          <p class="thesis-strip thesis-strip--dark">These are design inputs for a bounded pilot. They are not reasons to stop learning.</p>`,
        note: `<p>Frame these as current-state constraints, not failures. Do not call an unapproved integration a workaround. The question is how to validate one use case within policy, then use the evidence to justify the approved gateway, identity, UI, connector, and support path.</p>`
      },
      {
        label: "A realistic scale path",
        tone: "ink",
        html: `
          <div class="slide-topline"><p class="eyebrow eyebrow--light">FROM LAPTOP TO TEAM CAPABILITY</p>${badge("CONCEPT", "concept")}</div>
          <h2>Package the pattern.<br />Do not copy the laptop.</h2>
          <div class="scale-path">
            <article><small>01 • REGISTER</small><strong>One narrow use case</strong><p>Owner • outcome • source boundary • risk • measure</p></article>
            <article><small>02 • PROVE</small><strong>Read + draft pilot</strong><p>Approved data • tests • human review • evidence</p></article>
            <article><small>03 • PACKAGE</small><strong>Reusable Agent Kit</strong><p>EDMG • persona pack • tool contract • team config • runbook</p></article>
            <article><small>04 • SCALE</small><strong>Governed service</strong><p>Managed identity • AI Dome • simple front door • approved MCP path</p></article>
          </div>
          <p class="scale-rule">Teams configure their use case and knowledge. They do not copy credentials, fork scripts, or rewrite the control core.</p>`,
        note: `<p>The target is not a single giant chatbot. It is a reusable kit with stable orchestration and controls, plus team-specific knowledge and configuration. Narrow approved adapters may be an interim pattern only if the company approves them; an approved MCP implementation can replace those contracts later.</p>`
      },
      {
        label: "Match controls to consequences",
        tone: "paper",
        html: `
          <p class="eyebrow">SAFE EXPERIMENTATION</p>
          <h2>Match the controls to the consequence of the task.</h2>
          <div class="risk-zones">
            <article class="risk-green"><small>GREEN • START HERE</small><strong>Format, summarize, prototype</strong><p>Dummy or user-supplied nonsensitive content. Human reviews the result.</p></article>
            <article class="risk-yellow"><small>YELLOW • CONTROLLED</small><strong>Email, databases, scripts</strong><p>Approved sandbox, least privilege, testing, logging, human verification, technical escalation.</p></article>
            <article class="risk-red"><small>RED • DO NOT IMPROVISE</small><strong>Auto-send, write, delete, deploy</strong><p>Formal approval and production controls—or keep the action human-only.</p></article>
          </div>
          <div class="nonnegotiables"><span><b>1</b>Approved tools + data</span><span><b>2</b>Human owns consequential actions</span><span><b>3</b>Escalate what you cannot explain</span></div>`,
        note: `<p>Do not say the risks are small. Say they are manageable when the controls match the consequence. A business-friendly request can still touch restricted data, and a technical answer can still be advice-only. Response depth and action authority are separate control dials.</p>`
      },
      {
        label: "Prototype quickly productionize deliberately",
        tone: "aqua",
        html: `
          <div class="slide-topline"><p class="eyebrow">THE LEARNING LOOP</p>${badge("PRACTICE → SCALE", "prototype")}</div>
          <h2>Prototype quickly.<br />Productionize deliberately.</h2>
          <ol class="learning-loop">
            <li><span>01</span><strong>Find</strong><p>One narrow, repetitive task.</p></li>
            <li><span>02</span><strong>Sandbox</strong><p>Use safe data and bounded access.</p></li>
            <li><span>03</span><strong>Verify</strong><p>Check facts, logic, and edge cases.</p></li>
            <li><span>04</span><strong>Tune</strong><p>Record why the result changed.</p></li>
            <li><span>05</span><strong>Package</strong><p>Save instructions, examples, and controls as a skill.</p></li>
            <li><span>06</span><strong>Scale</strong><p>Only after value and risk gates pass.</p></li>
          </ol>
          <p class="thesis-strip">Tokens are an experimentation budget—not the outcome. The outcome is less repeated context, better drafts, and shorter review cycles.</p>`,
        note: `<p>Keep the urgency but refine the “race” language. The advantage comes from learning quickly and converting what works into a reliable capability. Early experimentation will be inefficient; the goal is to stop repeating the same context by turning the stable pattern into a skill.</p>`
      },
      {
        label: "Repeatable team use-case intake",
        tone: "ink",
        html: `
          <div class="slide-topline"><p class="eyebrow eyebrow--light">THE PRACTICAL END GOAL</p>${badge("DECISION NEEDED", "concept")}</div>
          <h2>Bring one task.<br />We turn it into a testable use case.</h2>
          <div class="intake-layout">
            <div class="intake-canvas"><span>Task + trigger</span><span>Frequency + effort</span><span>Inputs + sensitivity</span><span>Rules + exceptions</span><span>Tools required</span><span>Useful output</span><span>Human checkpoint</span><span>Failure impact</span><span>Success measure</span></div>
            <div class="intake-route"><article><small>TEAM</small><strong>One recurring task</strong></article><b>→</b><article><small>TRIAGE</small><strong>Business + technical + risk</strong></article><b>→</b><div class="intake-outcomes"><span>Sandbox</span><span>Pilot</span><span>Package</span><span>Scale</span><span>Stop</span></div></div>
          </div>
          <p class="final-question">What is one piece of work you would teach a new analyst to do—and what would have to be true before you trusted an agent to help?</p>`,
        note: `<p>Do not invite an uncontrolled wave of requests until the support path is real. Before presenting, confirm the intake owner, approved sandbox, technical review route, provisioning process, and sponsorship. A strong first candidate happens at least twice a month, takes roughly 30–90 minutes, has a recognizable good result, and allows human approval before any consequential action.</p><p>Close in your voice: our team owns the governance criteria and exceptions. Other teams may build governance technology, but our expertise must shape the capability early.</p>`
      }
    ]
  };
})();
