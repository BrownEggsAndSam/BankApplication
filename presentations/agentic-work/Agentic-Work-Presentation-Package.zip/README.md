# Agentic Work Presentations

Three standalone HTML presentations for explaining agentic work, turning the current prototype into a reusable business capability, and defining the operating model required to sustain it.

## Start here

Open `index.html` in a browser. No installation, database access, API token, or development environment is required.

- `from-buzzwords-to-better-work.html` — the 45-minute main story for nontechnical teams: the personal bridge, Agent–Skill–Harness, four use cases, safe experimentation, and team use-case intake.
- `team-adoption.html` — the productization proposal: what exists, the recommended pilot, the orchestration model, constraints, and the 90-day decision path.
- `building-to-last.html` — the operating model: ownership, modular architecture, knowledge governance, identity, testing, monitoring, releases, and adoption.

## Presenting

- Right arrow, down arrow, Page Down, or Space: next slide
- Left arrow, up arrow, or Page Up: previous slide
- `N`: show or hide speaker notes
- `F`: full screen
- Home / End: first or last slide
- Use **Print / PDF** to create a widescreen PDF copy

## Safe content choices

The supplied photo folders contained personal, gaming, chat, travel, identity, account, or other unrelated material rather than work-environment evidence. None of those images were embedded. The prototype views in the deck are sanitized visual reconstructions based only on the described workflow.

The main deck contains five labeled screenshot slots. Place approved, redacted images under `assets/work/` using the exact filenames in that folder’s README; the placeholders will be replaced automatically. Remove names, ticket identifiers, database details, URLs, account information, tokens, and confidential business data before sharing.

## Updating the deck

- Main-story narrative and notes: `buzzwords-deck.js`
- Supporting-deck narrative and notes: `decks.js`
- Visual style and print layout: `presentation.css`
- Navigation behavior: `presentation.js`
- Presentation library: `index.html`
- Work-computer instructions: `handoff/WORK-COMPUTER-HANDOFF.md`

Keep credentials and real system data out of this folder. The presentation is intentionally static and contains no connection to PostgreSQL, Jira, Confluence, Collibra, Pentaho, or the AI gateway.
